/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_336(unsigned x)
{
    return x + 2490483544U;
}

unsigned addval_185(unsigned x)
{
    return x + 3284631880U;
}

void setval_117(unsigned *p)
{
    *p = 3284633928U;
}

void setval_494(unsigned *p)
{
    *p = 3251079496U;
}

unsigned addval_325(unsigned x)
{
    return x + 3281016916U;
}

void setval_203(unsigned *p)
{
    *p = 2428995912U;
}

void setval_275(unsigned *p)
{
    *p = 3281031768U;
}

void setval_321(unsigned *p)
{
    *p = 2438493685U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_120(unsigned *p)
{
    *p = 3225996937U;
}

unsigned addval_153(unsigned x)
{
    return x + 3286272840U;
}

void setval_197(unsigned *p)
{
    *p = 3247493513U;
}

unsigned getval_334()
{
    return 3676360329U;
}

unsigned getval_297()
{
    return 3380924809U;
}

unsigned getval_356()
{
    return 3677408905U;
}

unsigned getval_250()
{
    return 3284306306U;
}

unsigned addval_390(unsigned x)
{
    return x + 3247493513U;
}

unsigned addval_208(unsigned x)
{
    return x + 3676885385U;
}

unsigned getval_253()
{
    return 2429455129U;
}

void setval_309(unsigned *p)
{
    *p = 3532967561U;
}

void setval_217(unsigned *p)
{
    *p = 3223372441U;
}

void setval_189(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_169()
{
    return 3525362377U;
}

void setval_473(unsigned *p)
{
    *p = 3676881545U;
}

unsigned addval_288(unsigned x)
{
    return x + 3372798361U;
}

void setval_440(unsigned *p)
{
    *p = 3281109641U;
}

unsigned addval_462(unsigned x)
{
    return x + 3515449440U;
}

unsigned getval_472()
{
    return 3676885385U;
}

unsigned getval_259()
{
    return 3372270217U;
}

void setval_115(unsigned *p)
{
    *p = 3229926017U;
}

void setval_204(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_482()
{
    return 3251538367U;
}

unsigned addval_221(unsigned x)
{
    return x + 3286272320U;
}

unsigned getval_105()
{
    return 3286272328U;
}

unsigned getval_151()
{
    return 2425409921U;
}

unsigned addval_475(unsigned x)
{
    return x + 3767093274U;
}

unsigned getval_164()
{
    return 3532967561U;
}

void setval_319(unsigned *p)
{
    *p = 3286273352U;
}

unsigned getval_470()
{
    return 2464188744U;
}

unsigned addval_124(unsigned x)
{
    return x + 3465130505U;
}

unsigned addval_157(unsigned x)
{
    return x + 3682910857U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
