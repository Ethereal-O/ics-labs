/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_465(unsigned *p)
{
    *p = 3284633930U;
}

void setval_336(unsigned *p)
{
    *p = 3260565665U;
}

void setval_499(unsigned *p)
{
    *p = 3243828183U;
}

unsigned getval_188()
{
    return 3277376828U;
}

unsigned addval_423(unsigned x)
{
    return x + 3277325479U;
}

void setval_279(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_166()
{
    return 3284633930U;
}

unsigned addval_346(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_252()
{
    return 3523789192U;
}

unsigned getval_304()
{
    return 3372794265U;
}

unsigned getval_170()
{
    return 3398277731U;
}

void setval_464(unsigned *p)
{
    *p = 3674789513U;
}

unsigned getval_409()
{
    return 3677935305U;
}

unsigned getval_125()
{
    return 3687104905U;
}

unsigned getval_353()
{
    return 2430634312U;
}

unsigned getval_189()
{
    return 3375939977U;
}

unsigned addval_276(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_360()
{
    return 3767093280U;
}

unsigned addval_172(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_492()
{
    return 3286272330U;
}

void setval_169(unsigned *p)
{
    *p = 3224944905U;
}

unsigned getval_380()
{
    return 2425411273U;
}

unsigned addval_217(unsigned x)
{
    return x + 3247494793U;
}

unsigned getval_301()
{
    return 3531129225U;
}

unsigned addval_433(unsigned x)
{
    return x + 3286270280U;
}

unsigned addval_368(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_102(unsigned x)
{
    return x + 3590974076U;
}

unsigned addval_487(unsigned x)
{
    return x + 2425670281U;
}

unsigned getval_358()
{
    return 2425408137U;
}

void setval_385(unsigned *p)
{
    *p = 3281114761U;
}

unsigned addval_420(unsigned x)
{
    return x + 2425405865U;
}

unsigned addval_311(unsigned x)
{
    return x + 3678980745U;
}

unsigned getval_377()
{
    return 3375942273U;
}

void setval_246(unsigned *p)
{
    *p = 3286288712U;
}

unsigned addval_339(unsigned x)
{
    return x + 3372272265U;
}

unsigned getval_140()
{
    return 3677929865U;
}

unsigned addval_128(unsigned x)
{
    return x + 3526940169U;
}

unsigned getval_231()
{
    return 3526940297U;
}

void setval_234(unsigned *p)
{
    *p = 3676359305U;
}

void setval_101(unsigned *p)
{
    *p = 3380136585U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
